
# Plan

- X Ingress
- X Certmanager:
    - Instalar Certificado de ejemplo
- X Dashbaroard
- X Crear namespaces (Dev, QA, Prod, DevOps)
- X Instalar Dron
- X Instalar Sonarqube

- Crear Ingress para Dashboard

- Instalar Metricbeats
- Instalar Filebeat
- Instalar Velero

# Pre-requisitos

- Crear Zona DNS
- Apuntar Dominio a DNS
- Crear Instancia de Application Gateway
- Crear Cluster AKS
- Crear Github

# Telegram
@Botfather
drone orgsecret add team-imagemaker telegram_token 1860294509:AAGs2LV6fjU75Bzq6qEqqX5ItzPIrJ0lZlg
