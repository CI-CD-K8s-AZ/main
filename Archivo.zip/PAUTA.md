
# Pre-requisitos

- Cluster AKS
- Zona DNS
- Registro de contenedor

# Pasos

1. Crear Cluster AKS
2. Crear Registro de Contenedor
3. Simular creación de Zona DNS
4. Mostrar estructura de "main"

5. Instalar Ingress Controller
6. Instalar Certmanager

- Build: Compilar
- Test: Unit Test
- Analysis: Sonarqube
- Package: Docker Image
- Push: Docker Image

- Deploy: Dev

---------------

- App Angular
- App SpringBoot

- main





---------------------


Paso 1
# Crear Namespaces

`
    kubectl create namespace dev
    kubectl create namespace qa
    kubectl create namespace prod
    kubectl create namespace devops
`

Paso 2
# Ingress Controller

`
    kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v0.47.0/deploy/static/provider/cloud/deploy.yaml
`

Paso 3
# Registrar DNS con Ingress

http://20.201.15.0/ --> metalcloud.cl


Paso 4
# Instalar Certmanager

`
    kubectl apply -f https://github.com/jetstack/cert-manager/releases/download/v1.4.0/cert-manager.yaml
    kubectl apply -f ./Certmanager/issuer.yaml
`

Paso 5
# Instalar Kubernetes Dashboard

`
    kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.2.0/aio/deploy/recommended.yaml
    kubectl apply -f ./Dashboard/ingress.yaml
    kubectl apply -f ./Dashboard/rbac.yaml
`

Para obtener un token:

`
    secret=$(kubectl -n kubernetes-dashboard get secret | grep kubernetes-dashboard-token | awk '{print $1}')
    token=$(kubectl -n kubernetes-dashboard get secret $secret --template={{.data.token}} | base64 -d)
    echo "$token" | pbcopy # pbcopy: Solo en Mac, copia al portapapeles
`

Paso 6
# Instalar DroneCI

Crear token de Bitbucket y Agregarlo al secret, luego:

`
    kubectl apply -f ./DroneCI/postgres/postgres.yaml
    kubectl apply -f ./DroneCI/server/
    kubectl apply -f ./DroneCI/runner/
`

Paso 7
# Instalar ArgoCD

`
    kubectl apply -n devops -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
    kubectl apply -f ./ArgoCD/ingress.yaml
    kubectl apply -f ./ArgoCD/rbac.yaml
`

Para obtener la contraseña de admin:

`
    kubectl -n devops get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d | pbcopy # pbcopy: Solo en Mac, copia al portapapeles
`

Paso 8
# Instalar Sonarqube

Para instalarlo solo debes ejecutar el siguiente comando:

`
    git clone https://github.com/SonarSource/helm-chart-sonarqube.git
    cd helm-chart-sonarqube/charts/sonarqube
    helm dependency update
    helm upgrade --install -f values.yaml -n devops sonar ./ --set "ingress.enabled=true,ingress.hosts[0].name=sonar.metalcloud.cl"

    kubectl patch ingress -n devops sonar-sonarqube -p '{"metadata":{"annotations": { "cert-manager.io/cluster-issuer" : "letsencrypt-prod"}}}'

    kubectl patch ingress -n devops sonar-sonarqube -p '{"spec":{"tls": [ { "hosts": [ "sonar.metalcloud.cl" ], "secretName":  "sonar-secret-tls"  } ] }}'

    cd ../../../
    rm -R helm-chart-sonarqube
`

Luego de generar el token y crear el secret

Paso 9
(My Account –> Security –> Generate Tokens)

Paso 10
# Crear API Telegram

drone orgsecret add CI-CD-K8s-AZ telegram_token 1860294509:AAGs2LV6fjU75Bzq6qEqqX5ItzPIrJ0lZlg --allow-pull-request
drone orgsecret add CI-CD-K8s-AZ sonar_host https://sonar.metalcloud.cl --allow-pull-request
drone orgsecret add CI-CD-K8s-AZ sonar_token f9f2f6ab86a193781f8817a164809214417938ce --allow-pull-request

drone orgsecret add CI-CD-K8s-AZ registry_username metalcloud --allow-pull-request
drone orgsecret add CI-CD-K8s-AZ registry_password gFSxydmo79929lswdbUgwPosTMeOvM7+ --allow-pull-request

-------------------------

az aks update -n metalcloud -g metalcloud --attach-acr metalcloud

kubectl create secret docker-registry azure-registry \
    --namespace devops \
    --docker-server=metalcloud.azurecr.io \
    --docker-username=metalcloud \
    --docker-password=gFSxydmo79929lswdbUgwPosTMeOvM7+

kubectl create secret docker-registry azure-registry2 \
    --namespace dev \
    --docker-server=metalcloud.azurecr.io \
    --docker-username=metalcloud \
    --docker-password=gFSxydmo79929lswdbUgwPosTMeOvM7+

kubectl create secret docker-registry azure-registry \
    --namespace qa \
    --docker-server=metalcloud.azurecr.io \
    --docker-username=metalcloud \
    --docker-password=gFSxydmo79929lswdbUgwPosTMeOvM7+

kubectl create secret docker-registry azure-registry \
    --namespace prod \
    --docker-server=metalcloud.azurecr.io \
    --docker-username=metalcloud \
    --docker-password=gFSxydmo79929lswdbUgwPosTMeOvM7+

feat -[PR]-> develop --> Deploy a Desarrollo
develop -[PR]-> release --> Deploy a QA
release -[PR]-> master --> Deploy a Produccion


{"auths":{"imrgtry.azurecr.io":{"username":"imrgtry","password":"Yp/bn17w2a3Z4fpbTAf7thzPrykrCdd4","email":"jenkins@imagemaker.com","auth":"aW1yZ3RyeTpZcC9ibjE3dzJhM1o0ZnBiVEFmN3RoelByeWtyQ2RkNA=="}}}

{"auths":{"metalcloud.azurecr.io":{"username":"metalcloud","password":"gFSxydmo79929lswdbUgwPosTMeOvM7","auth":"bWV0YWxjbG91ZDpnRlN4eWRtbzc5OTI5bHN3ZGJVZ3dQb3NUTWVPdk03"}}}
