# Instalar Kubernetes Dashboard

Para instalarlo solo debes ejecutar el siguiente comando:

kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.2.0/aio/deploy/recommended.yaml
